import "%modules%/header/header";
import "%modules%/welcome/welcome";
import "%modules%/projects/projects";
import "%modules%/faq/faq";
import "%modules%/footer/footer";
import "%modules%/popup/popup";
import "%modules%/form/form";